function plot_G_sr_dev(sr_int, test_err_g_sr)
% plot development of spectral radius vs. MSE 

% #########################################################################
% INPUT 1: sr_int (list of spectral radii)
% INPUT 2: test_err_g_sr (testing errors of the generator for specific
% spectral radii)
% OUTPUT: plot
% #########################################################################

figure;
plot(sr_int, test_err_g_sr, 'LineWidth', 2)
title('Evolution of MSE w.r.t. spectral radius')
xlabel('spectral radius')
ylabel('MSE')

end