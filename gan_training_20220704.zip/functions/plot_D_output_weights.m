function plot_D_output_weights(beta)
% plot output weights of discriminator

% #########################################################################
% INPUT: beta (obtained output weights beta)
% OUTPUT: plot
% #########################################################################

plot(beta, 'LineWidth', 2)
title('d) Output weights \beta')
xlim([1, length(beta)])
xlabel('Node')
ylabel('Value')

end