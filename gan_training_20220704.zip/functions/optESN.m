%% Generator - ESN approach
function [err_out, theta, c, A] = optESN(hyp_g, z, Y_target, T, rand_seed)
% optimize the ESN's parameters

% #########################################################################
% INPUT 1: hyp_g (generator hyperparameters)
% INPUT 2: z (input set)
% INPUT 3: Y_target (desired target)
% INPUT 4: T (length of each sample)
% INPUT 5: rand_seed (specification of random seed)
% OUTPUT 1: err_out (error measure's output)
% OUTPUT 2: theta (generator's output weights)
% OUTPUT 3: c (input weight matrix)
% OUTPUT 4: A (reservoir weight matrix)
% #########################################################################

% initialize
N_u = size(z, 1);
len_z = size(z, 2);
M = size(z, 3);
N_tilde_G = hyp_g(3);
N_tilde_G_min = N_tilde_G-1;

% compute weights matrices for ESN (without intercept)
intercept = 0;
[c, A] = compute_ESN_weights(hyp_g, N_u, intercept, rand_seed);
rn = 0.001.*rand(N_tilde_G_min, len_z+1, M);
        
x_hat = zeros(N_tilde_G_min, len_z+1, M);
S = zeros(N_tilde_G, T, M);
for i=1:M
    for t=2:len_z+1
        % collect the reservoir activation states
        if intercept == 1
            x_hat(:, t, i) = tanh(c*[1; z(:, t-1, i)] + A*x_hat(:, t-1, i));
        elseif intercept == 0
%             x_hat(:, t, i) = tanh(c*z(:, t-1, i) + A*x_hat(:, t-1, i) + rn(:, t-1, i));
            x_hat(:, t, i) = tanh(c*z(:, t-1, i) + A*x_hat(:, t-1, i));
        else
            error('Declare intercept!')
        end
    end
    % erase initial transient and add intercept
    S(:,:,i) = [ones(1, T); x_hat(:, (end-T+1):end, i)];
end

%##########################################################################
% training W_out via ridge regression
%##########################################################################
theta = zeros(M, N_tilde_G);
Y = zeros(M, T);
lambda = 1e-5; % regularization factor
% IC = zeros(1, M);
for i=1:M
    theta(i,:) = (Y_target(i,:)*S(:,:,i)') / (S(:,:,i)*S(:,:,i)' + ...
        lambda.*eye(N_tilde_G));
    Y(i,:) = theta(i,:) * S(:,:,i);
    %     IC(i) = mean(Y_target(i,:)) - (mean(S(:,:,i),2))'*W_out(i,:)';
end
%##########################################################################

% calculate error
err_out = RMSE(Y, Y_target);

end