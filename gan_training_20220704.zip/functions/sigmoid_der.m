function y = sigmoid_der(x)
% sigmoid derivative
y = sigmoid(x).*(1-sigmoid(x));
end