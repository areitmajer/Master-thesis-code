function plot_D_train_test_err_comp(train_err_d, test_err_d, nnd_list)
% plot comparison of optimized training vs. testing errors for the
% discriminator

% #########################################################################
% INPUT 1: train_err_d (optimized training errors of the discriminator)
% INPUT 2: test_err_d (testing errors of the discriminator)
% INPUT 3: nnd_list (list of number of hidden nodes)
% OUTPUT: plot
% #########################################################################

% find best hyperparam set
[min_ELM_hist_eval, min_ind_d] = min(test_err_d);
% disp(['Min value in ELM_list_fval: ', num2str(min_ELM_hist_eval)]);
% hyp_d_pretr = [hyp_d_list(min_ind_d, :), nnd_list(min_ind_d)];

plot(nnd_list, train_err_d, 'LineWidth', 2); 
hold on
plot(nnd_list, test_err_d, 'LineWidth', 2);
scatter(nnd_list(min_ind_d), min_ELM_hist_eval, 40,'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],'LineWidth',1.5)
legend({'Training error', 'Testing error', 'Optimal testing error'}, 'Location', 'northeast')
title('b) Comparison of training error and testing error')
subtitle('(Discriminator)')
xlim([nnd_list(1), nnd_list(end)])
xlabel('Number of hidden nodes')
ylabel('Mod. F1 score')
hold off

end