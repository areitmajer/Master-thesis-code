function [beta_hat, a, b] = disc_update(x, T, hyp_d)
% update ELM

% #########################################################################
% INPUT 1: x (time series)
% INPUT 2: T (set of targets)
% INPUT 3: hyp_d (discriminator hyperparameters)
% OUTPUT 1: beta_hat (output weights)
% OUTPUT 2: a (input weight matrix)
% OUTPUT 3: b (hidden bias)
% #########################################################################

% initialize 
M = size(x, 1);
numObs = size(x, 2);

% compute weights
[a, b] = compute_ELM_weights(hyp_d, numObs);

% calculate hidden layer output matrix
H = x*a + repmat(b, M, 1);

% apply radbas activation function on H
H_act = radbas(H);

% calculate output weights
H_MP = pinv(H_act);
beta_hat = H_MP * T;

end