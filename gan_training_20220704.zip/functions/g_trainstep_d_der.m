function res_cum = g_trainstep_d_der(x, beta, a, b)
% calculate discriminator's derivative w.r.t. input x

% #########################################################################
% INPUT 1: x (input sample)
% INPUT 2: beta (output weights of the discriminator)
% INPUT 3: a (input weight matrix)
% INPUT 4: b (hidden biases)
% OUTPUT: res_cum (derivative of discriminator w.r.t. x)
% #########################################################################

% initialize
numNeurons_d = length(beta);
M = size(x, 1);
numObs = size(x, 2);
res = zeros(M, numObs, numNeurons_d);
res_cum = zeros(M, numObs);

% calculate output matrix of hidden layer
H = x*a + repmat(b, M, 1);

% apply activation function on H
H_act = radbas(H);

for i=1:M
    for j=1:numObs
        for m=1:numNeurons_d
            res(i,j,m) = beta(m).*H_act(i,m).*(-2).*H(i,m).*a(j,m);
        end
        res_cum(i,j) = sum(res(i,j,:));
    end
end

end