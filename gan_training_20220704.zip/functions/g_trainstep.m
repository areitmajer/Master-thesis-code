function [g_loss_end, theta_opt, G_z, hist_grad_g_loss, m, v, m_hat, v_hat] = ...
    g_trainstep(z, T, beta, a, b, theta, nng, lr, ...
    hist_grad_g_loss, epoch, m, v, m_hat, v_hat, c, A)
% calculate generator's loss and its gradient

% #########################################################################
% INPUT 1: z (input set)
% INPUT 2: T (number of datapoints in each sample)
% INPUT 3: beta (output weights of discriminator)
% INPUT 4: a (input weight matrix)
% INPUT 5: b (hidden biases)
% INPUT 6: theta (output weights of generator)
% INPUT 7: nng (number of neurons used for the generator)
% INPUT 8: lr (learning rate)
% INPUT 9: hist_grad_g_loss (history of loss of generator's gradient)
% INPUT 10: epoch (number of epoch)
% INPUT 11: m (biased mean estimate for ADAM)
% INPUT 12: v (biased variance estimate for ADAM)
% INPUT 13: m_hat (bias-corrected mean estimate for ADAM)
% INPUT 14: v_hat (bias-corrected variance estimate for ADAM)
% INPUT 15: c (input weight matrix)
% INPUT 16: A (reservoir weight matrix)
% OUTPUT 1: g_loss_end (generator's loss after updates)
% OUTPUT 2: theta_opt (optimal output weights for generator)
% OUTPUT 3: G_z (generator's output)
% OUTPUT 4: hist_grad_g_loss (history of loss of generator's gradient)
% OUTPUT 5: m (biased mean estimate for ADAM)
% OUTPUT 6: v (biased variance estimate for ADAM)
% OUTPUT 7: m_hat (bias-corrected mean estimate for ADAM)
% OUTPUT 8: v_hat (bias-corrected variance estimate for ADAM)
% #########################################################################

% initialize
M = size(z, 3);

% select optimizer type (either SGD or ADAM)
G_optimizer = "ADAM";

% display status
disp('Train generator')

% calculate gradient of generator's loss w.r.t. theta
[Y, S] = gen(z, theta, nng, T, c, A);
G_z = sample_transform(Y, 0);
d_fake = disc(G_z, beta, a, b);
D_der = g_trainstep_d_der(G_z, beta, a, b);
N_der = zeros(T, T, M);
for i=1:M
    N_der(:,:,i) = g_trainstep_normalize_der(Y(i,:));
end

% calculate gradient
grad_iter = zeros(M, nng);
for i = 1:M
    grad_iter(i,:) = -(1/M) .* log_der(sigmoid(d_fake(i,:))) .* sigmoid_der(d_fake(i,:)) .* ...
        (D_der(i,:) * (N_der(:,:,i) * S(:,:,i)'));
end
grad_g_loss = sum(grad_iter);

% store gradient of generator's loss
hist_grad_g_loss(epoch, :) = grad_g_loss;

if G_optimizer == "SGD"
    theta_opt = theta - lr.*grad_g_loss;
elseif G_optimizer == "ADAM"
    beta_1 = 0.9;
    beta_2 = 0.999;
    adam_eps = 1e-8;
    m(epoch+1, :) = beta_1.*m(epoch, :) + (1-beta_1).*grad_g_loss;
    v(epoch+1, :) = beta_2.*v(epoch, :) + (1-beta_2).*grad_g_loss.^2;
    m_hat(epoch+1, :) = m(epoch+1, :)./(1-beta_1.^epoch);
    v_hat(epoch+1, :) = v(epoch+1, :)./(1-beta_2.^epoch);
    theta_opt = theta - ((lr./(sqrt(v_hat(epoch+1, :)) + adam_eps)).*m_hat(epoch+1, :));
else
    error('Please enter a valid optimizer type!')
end

% check optimized theta for NaN entries
if sum(isnan(theta_opt)) > 0
    error('NaN entry found in theta_opt')
end

% calculate generator's loss with optimized theta
g_loss_end = g_loss(z, theta_opt, nng, T, c, A, beta, a, b);

end