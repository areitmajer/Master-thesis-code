function [mod_f1, beta, a, b] = optELM(hyp_d, ts, ts_labels, beta, a, b)
% optimize the ELM's parameters

% #########################################################################
% INPUT 1: hyp_d (discriminator hyperparameters)
% INPUT 2: ts (set of time series contained row-wise)
% INPUT 3: ts_labels (set of labels corresponding to ts)
% INPUT 4 (optional): beta (output weights)
% INPUT 5 (optional): a (input weight matrix)
% INPUT 6 (optional): b (bias)
% OUTPUT 1: mod_f1 (modified F1 score)
% OUTPUT 2: beta (discriminator's output weights)
% OUTPUT 3: a (input weight matrix)
% OUTPUT 4: b (bias)
% #########################################################################

if nargin == 3
    % train ELM / fit the model on training dataset
    [beta, a, b] = disc_update(ts, ts_labels, hyp_d);

    % evaluate ELM on training dataset (in-sample evaluation)
    y_pred = sigmoid(disc(ts, beta, a, b));
    y_true = sigmoid(ts_labels);
elseif nargin == 6
    % evaluate ELM on testing dataset (out-of-sample evaluation)
    y_pred = sigmoid(disc(ts, beta, a, b));
    y_true = sigmoid(ts_labels);
else
    error('Something wrong with input arguments')
end

% calculate true positives, false positives, false negatives
tp1 = y_pred'*y_true;
fp1 = y_pred'*(1-y_true);
fn1 = (1-y_pred)'*y_true;

%Approach 1: Mallows correlation
p = tp1 / (tp1 + fp1 + eps);
r = tp1 / (tp1 + fn1 + eps);
fval_mal_cor = 1-((2*p*r) / (p+r+eps));

%Approach 2: F1 score modified
mod_f1 = 1 - mean((2.*tp1) ./ ((2.*tp1) + fn1 + fp1));

%Approach 3: pure F1 score - not good!
% d_res = d_res>0.5;
% tp = sum(d_res .* y_labels);
% fp = sum(d_res .* (1-y_labels));
% fn = sum((1 - d_res) .* y_labels);
% fval = 1 - mean(2.*tp ./ (2.*tp + fn + fp));

%Approach 4: loglik
% sum_logL = 0;
% for i=1:length(ts_class)
%     sum_logL = (ts_class(i).*W(i) + (1-ts_class(i))*log(1-(W(i)))) + sum_logL;
% end
% fval = -sum_logL;

end