function Y_tf = sample_gen(z, theta, nng, T, c, A, flag)
% generate sample with ESN 

% #########################################################################
% INPUT 1: z (input set)
% INPUT 2: theta (output weights)
% INPUT 3: nng (number of neurons used in the generator)
% INPUT 4: T (number of datapoints in each sample)
% INPUT 5: c (input weight matrix)
% INPUT 6: A (reservoir weight matrix)
% INPUT 7 (optional): flag
% OUTPUT: Y_tf (transformed ESN's output)
% #########################################################################

% initialize
M = size(z, 3);

% generate samples with ESN
if nargin == 7
    Y = zeros(M, T);
    for i=1:M
        Y(i,:) = gen(z(:,:,i), theta(i,:), nng, T, c, A);
    end
elseif nargin == 6
    Y = gen(z, theta, nng, T, c, A);
else
    error('Something wrong with input arguments')
end

% transform generated samples
Y_tf = sample_transform(Y, 0);

end