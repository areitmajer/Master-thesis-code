function plot_hist_comp(real_path, gen_paths)
% compare real and generated densities via histograms

% #########################################################################
% INPUT 1: real_path (historic real S&P 500 path)
% INPUT 2: gen_paths (generated paths from trained ESN)
% OUTPUT: plot
% #########################################################################

% initialize
log_r_hist1 = log_r(real_path, 1);
log_r_hist5 = log_r(real_path, 5);
log_r_hist20 = log_r(real_path, 20);
log_r_hist100 = log_r(real_path, 100);

log_r_gen1 = log_r(gen_paths, 1);
log_r_gen5 = log_r(gen_paths, 5);
log_r_gen20 = log_r(gen_paths, 20);
log_r_gen100 = log_r(gen_paths, 100);

rng('default')
M = size(gen_paths, 1);
numSamp = randperm(M, 1);

% create plot of histogram comparing real and generated densities
figure;
subplot(2,2,1)
create_hist_plot(log_r_hist1, log_r_gen1(numSamp, :), '(a) Daily', '1-day log-return', 3e-3)
subplot(2,2,2)
create_hist_plot(log_r_hist5, log_r_gen5(numSamp, :), '(b) Weekly', '5-day log-return', 5e-3)
subplot(2,2,3)
create_hist_plot(log_r_hist20, log_r_gen20(numSamp, :), '(c) Monthly', '20-day log-return', 6e-3)
subplot(2,2,4)
create_hist_plot(log_r_hist100, log_r_gen100(numSamp, :), '(d) 100-day', '100-day log-return', 1e-2)

end 

function create_hist_plot(log_r_hist, log_r_gen, hist_title, hist_x_label, binW)
hist_real = histogram(log_r_hist, 10);
hold on
hist_fake = histogram(log_r_gen, 10);
xlabel(hist_x_label)
ylabel('PDF')
title(hist_title)
legend('historical', 'generated')
hold off

hist_real.Normalization = 'pdf';
hist_real.FaceAlpha = 0.5;
hist_real.FaceColor = 'blue';
% hist_real.EdgeColor = 'red';
hist_real.BinWidth = binW;
hist_fake.Normalization = 'pdf';
hist_fake.FaceAlpha = 0.5;
hist_fake.FaceColor = 'red';
% hist_fake.EdgeColor = 'red';
hist_fake.BinWidth = binW;
end

function create_acf_plot(log_r_hist, log_r_gen, numLags, acf_title)
acf_real = autocorr(log_r_hist, 'NumLags', numLags);

acf_fake_list = zeros(size(log_r_gen, 1), numLags+1);
for i=1:size(log_r_gen, 1)
    acf_fake_list(i,:) = autocorr(log_r_gen(i,:), 'NumLags', numLags);
end
acf_fake = mean(acf_fake_list);

acf_fake_std = std(acf_fake_list);
ub_acf_fake = acf_fake + acf_fake_std;
lb_acf_fake = acf_fake - acf_fake_std;

x_int = 1:numLags;

hold on
plot(acf_real(2:end), 'DisplayName', 'Historical')
plot(acf_fake(2:end), 'DisplayName', 'Generated')
plot(ub_acf_fake(2:end), '--r', 'DisplayName', 'upper bound')
plot(lb_acf_fake(2:end), '--r', 'DisplayName', 'lower bound')
patch([x_int fliplr(x_int)], [lb_acf_fake(2:end) fliplr(ub_acf_fake(2:end))], ...
    'r', 'DisplayName', 'CI')
alpha(0.2)
hold off
grid on
xlabel('Lags')
ylabel('ACF')
title(acf_title)
xlim([0, numLags])
legend
end

function create_lev_eff_plot(log_r_hist, log_r_gen, numLags)
lev_eff_real = lev_eff(log_r_hist, numLags);
lev_eff_fake_list = lev_eff(log_r_gen, numLags);
lev_eff_fake = mean(lev_eff_fake_list, 1);

lev_eff_std_fake = std(lev_eff_fake_list);
ub_lev_eff = lev_eff_fake + lev_eff_std_fake;
lb_lev_eff = lev_eff_fake - lev_eff_std_fake;

x_int_lev_eff = 1:numLags;

hold on
plot(lev_eff_real(2:end), 'DisplayName', 'Historical')
plot(lev_eff_fake(2:end), 'DisplayName', 'Generated')
plot(ub_lev_eff(2:end), '--r', 'DisplayName', 'upper bound')
plot(lb_lev_eff(2:end), '--r', 'DisplayName', 'lower bound')
patch([x_int_lev_eff fliplr(x_int_lev_eff)], [lb_lev_eff fliplr(ub_lev_eff)], ...
    'r', 'DisplayName', 'CI')
alpha(0.3)
hold off
xlabel('Lags')
ylabel('Leverage Effect')
title('(d) Leverage effect')
xlim([0, numLags])
grid on
legend
end
