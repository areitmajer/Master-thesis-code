function res = g_trainstep_normalize_der(x)
% normalize derivative function

% #########################################################################
% INPUT: x (input sample)
% OUTPUT: res (normalized derivative)
% #########################################################################

n = length(x);
res = zeros(n,n);
for k=1:n
    for j=1:n
        res(k,j) = normalize_der_component(x, k, j, mean(x), std(x));
    end
end

end

function res = normalize_der_component(x, k, j, mean_x, std_x)
calc_std_der = std_der(x, j, mean_x, std_x);
calc_mean_der = mean_der(x);
if k==j
    res = ((std_x - (x(j)*calc_std_der))/(std_x^2)) - ...
        (((calc_mean_der*std_x)-(mean_x*calc_std_der))/(std_x^2));
else
    res = (x(k)*(-(std_x^(-2)))*calc_std_der) - ...
        (((calc_mean_der*std_x)-(mean_x*calc_std_der))/(std_x^2));
end
end

function res = mean_der(x)
res = 1/length(x);
end

function res_alt = std_der(x, j, mean_x, std_x)
n = length(x);
mult_vec = ones(1,n);
mult_vec(j) = 0;
sum_std_alt = mult_vec*((2/n).*(-1/n).*(x'-mean_x));
res_alt = 0.5*((std_x^2)^(-0.5))*(sum_std_alt + ((2/n)*(x(j)-mean_x)*(1-(1/n))));
end