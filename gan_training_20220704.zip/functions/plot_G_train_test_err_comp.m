function plot_G_train_test_err_comp(train_err_g, test_err_g, nng_list, N_G_train)
% plot comparison of optimized training errors vs. testing errors for the
% generator

% #########################################################################
% INPUT 1: train_err_g (optimized generator's training errors)
% INPUT 2: test_err_g (generator's testing errors)
% INPUT 3: nng_list (list of number of neurons)
% INPUT 4: N_G_train (specification of training length)
% OUTPUT: plot
% #########################################################################

% find best hyperparameter set (generator)
[min_ESN_hist_eval, min_ind_g] = min(test_err_g);
disp(['Min value in ESN_list_fval: ', num2str(min_ESN_hist_eval)]);

plot(nng_list, train_err_g, 'LineWidth', 2); 
hold on
plot(nng_list, test_err_g, 'LineWidth', 2);
scatter(nng_list(min_ind_g), min_ESN_hist_eval, 40,'MarkerEdgeColor',[0 .5 .5],...
              'MarkerFaceColor',[0 .7 .7],'LineWidth',1.5)
legend({'Training error', 'Testing error', 'Optimal testing error'}, ...
    'Location', 'northwest')
xlim([nng_list(1), nng_list(end)])
% title(['N_GTrain= ', num2str(N_G_train)])
title('b) Comparison of training error and testing error')
subtitle('(Generator)')
xlabel('Number of hidden nodes')
ylabel('RMSE')
hold off

end