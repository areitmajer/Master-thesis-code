function plot_GAN_real_synt(real_path, gen_paths, num_paths)
% plot real path and generated paths with ESN 

% #########################################################################
% INPUT 1: real_path (original S&P 500 path)
% INPUT 2: gen_paths (set of generated paths from the ESN)
% INPUT 3: num_paths (number of paths to be considered)
% OUTPUT: plot
% #########################################################################

figure;
subplot(2,1,1)
grid on
plot(gen_paths(1:num_paths, :)')
hold on
plot(real_path, 'magenta', 'LineWidth', 2)
title('Synthetic paths')
xlabel('t (days)')
ylabel('Spot price')
xlim([0, size(gen_paths, 2)])

subplot(2,1,2)
plot(real_path)
title('Original S&P 500 path')
xlabel('t (days)')
ylabel('Spot price')
xlim([0, size(real_path, 2)])
grid off

end