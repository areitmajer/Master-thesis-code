function x_exp = sample_inv_transform(x, self_mean, self_std)
% apply inverse transformation on sample

% #########################################################################
% INPUT 1: x (input sample)
% INPUT 2: self_mean (original series' mean)
% INPUT 3: self_std (original series' standard deviation)
% #########################################################################

% apply inverse standard scaler transform
x_inv_norm = x*self_std + self_mean;

% apply inverse difference transform
x_cumsum = cumsum(x_inv_norm, 2);

% apply exp inverse transform
x_exp = exp(x_cumsum); % inverse transformed sample

end