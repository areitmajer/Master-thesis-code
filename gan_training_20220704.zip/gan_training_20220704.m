
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Supervisor: Lyudmila Grigoryeva
% Author: Adrian Reitmajer
% University: University of Constance
% Year: 2021/2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialize 
clear variables
clc
close all

% add functions folder to the search path
addpath('functions')
addpath('dataset')

% set discriminator optimization steps
d_opt_steps = 1;

% set batch size
M = 100;

% set number of datapoints contained in each sample
T = 127;

% % number of neurons
% N_tilde_D = 300; % 400
% N_tilde_G = 200; % 300

% % initial values for parameters beta and theta
% beta = -0.1+0.2.*rand(numNeurons_d+1, 1);
% theta = -20+40.*rand(1, numNeurons_g);

% hist_acc_d_real = zeros(1, numEpochs);
% hist_acc_d_fake = zeros(1, numEpochs);

% % set start
% start = 1;
% 
% % set success
% success = false;

% define labels
label_real = 2.2;
label_fake = -2.2;

% load S&P 500 time series
dataset = load('sp500_dataset.mat');
ts_sp500 = double(dataset.samp_real_raw);
len_ts_sp500 = length(ts_sp500);

% transform S&P 500 time series
[ts_sp500_pp, mean_ts_sp500, std_ts_sp500] = sample_transform(ts_sp500, 1);
len_ts_sp500_pp = length(ts_sp500_pp);

% conduct ADF test
[ADF_h,ADF_pValue,ADF_stat,ADF_cValue,~] = adftest(ts_sp500_pp);

% estimate GARCH(1,1) model parameters
Mdl = garch(1,1);
EstMdl = estimate(Mdl, ts_sp500_pp'); 
% EstMdl params: Constant=0.0519, GARCH=0.7667, ARCH=0.1828
PertMdl = garch('Constant',0.06,'GARCH',0.5,'ARCH',0.1,'Offset',0); 

% simulate 100 GARCH(1,1) paths from perturbed model MdlPert
rng('default'); % for reproducibility
[~, path_sim] = simulate(PertMdl,len_ts_sp500_pp,'NumPaths',100);
[~, path_sim_est] = simulate(EstMdl, len_ts_sp500_pp,'NumPaths',100);
path_sim = transpose(path_sim);
path_sim_est = transpose(path_sim_est);

% initialize
samp_sp500_garch = zeros(len_ts_sp500-(T+1), T);
samp_sp500_real = zeros(len_ts_sp500-(T+1), T);

% cut simulated paths from GARCH(1,1) into subsamples
for j=1:size(path_sim, 1)
    for i=1:len_ts_sp500-(T+1)
        samp_sp500_garch(i,:,j) = path_sim(j, 1+(i-1):T+(i-1));
    end
end

% cut preprocessed S&P 500 time series into subsamples
for i=1:len_ts_sp500-(T+1)
    samp_sp500_real(i,:) = ts_sp500_pp(:, 1+(i-1):T+(i-1));
end

% shuffle real samples
rng('default')
samp_size = size(samp_sp500_real, 1);
samp_real_all = samp_sp500_real(randperm(samp_size), :);

% shuffle fake samples (first GARCH(1,1) path)
samp_fake_all = samp_sp500_garch(randperm(samp_size), :, 1);

% concatenate both sample types and generate labels
samp_all = [samp_real_all; samp_fake_all];
gamma = 0.05;
samp_labels_all = [label_real.*ones(samp_size, 1) + gamma.*rand(samp_size, 1); ...
    label_fake.*ones(samp_size, 1) - gamma.*rand(samp_size, 1)];
% samp_labels_all = [label_real.*ones(samp_size, 1); label_fake.*ones(samp_size, 1)];

% generate training/testing sets with real and/or fake data and
% corresponding labels
samp_size_mod = 1500; % fraction of samp_size
samp_real_train = samp_real_all(1:samp_size_mod, :);
samp_fake_train = samp_fake_all(1:samp_size_mod, :);
samp_real_test = samp_real_all(samp_size_mod+1:samp_size, :);
samp_fake_test = samp_fake_all(samp_size_mod+1:samp_size, :);
samp_train = [samp_real_train; samp_fake_train];
samp_labels_train = [samp_labels_all(1:samp_size_mod); ...
    samp_labels_all(samp_size+1:samp_size+samp_size_mod)];
samp_test = [samp_real_test; samp_fake_test];
samp_labels_test = [samp_labels_all(samp_size_mod+1:samp_size); ...
    samp_labels_all(samp_size+samp_size_mod+1:2*samp_size)];

% randomly shuffle training dataset
rng('shuffle')
ind_fold = randperm(2*samp_size_mod);
samp_rand = samp_train(ind_fold, :);
samp_rand_labels = samp_labels_train(ind_fold, :);

%% ADDITIONAL PLOTS

% plot original and preprocessed S&P 500 series
figure;
subplot(2,1,1)
plot(ts_sp500, 'LineWidth', 2)
title('Original S&P 500 series')
xlabel('Time')
ylabel('Value')
xlim([0 length(ts_sp500)])
subplot(2,1,2)
plot(ts_sp500_pp, 'LineWidth', 2)
title('Pre-processed S&P 500 series')
xlabel('Time')
ylabel('Value')
xlim([0 length(ts_sp500)])
ylim([min(ts_sp500_pp), max(ts_sp500_pp)])
hold off

% plot ACF & PACF of original S&P 500 series
figure; sgtitle('Original S&P 500 series');
hold on
subplot(2,1,1); autocorr(ts_sp500, 'NumLags', 300); title('ACF'); 
subplot(2,1,2); parcorr(ts_sp500, 'NumLags', 300); title('PACF'); 
hold off

% plot ACF & PACF of preprocessed S&P 500 series
figure; sgtitle('Preprocessed S&P 500 series');
hold on
subplot(2,1,1); autocorr(ts_sp500_pp, 'NumLags', 300); title('ACF'); 
subplot(2,1,2); parcorr(ts_sp500_pp, 'NumLags', 300); title('PACF'); 
hold off

%% ELM PRE-TRAINING

% initialize
nnd_list = 100:100:2000; % specify a list with number of neurons
hyp_d_start_no = [1, 1]; % set hyperparameters which are Not Optimized
len_nnd_list = length(nnd_list);
hyp_d_list = zeros(len_nnd_list, 2);
train_err_d = zeros(1, len_nnd_list);
train_err_d_np = zeros(1, len_nnd_list);
test_err_d = zeros(1, len_nnd_list);

% run optimization procedure
for t = 1:len_nnd_list
    % determine number of hidden nodes
    N_tilde_D = nnd_list(t);
    
    % training step
    train_err_d_np(t) = optELM([hyp_d_start_no, N_tilde_D], samp_train, samp_labels_train);
    funD = @(d_scale) optELM([d_scale, N_tilde_D], samp_train, samp_labels_train);
    options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm','sqp');
    [hyp_d_temp, ~] = fmincon(funD,hyp_d_start_no,[],[],[],[],[0.01,0.01],[10,10],[],options);
    hyp_d_list(t, :) = hyp_d_temp;
%     hyp_d_temp = hyp_d_list(t,:);
    [train_err_temp, beta_temp, a_temp, b_temp] = ...
        optELM([hyp_d_temp, N_tilde_D], samp_train, samp_labels_train);
    train_err_d(t) = train_err_temp;
    
    % testing step
    test_err_d(t) = optELM([hyp_d_temp, N_tilde_D], samp_test, ...
        samp_labels_test, beta_temp, a_temp, b_temp);
    
    % display current status
    disp(['Number of neurons: ', num2str(N_tilde_D), ', F1 train: ', ...
        num2str(train_err_d(t)), ', F1 test: ', num2str(test_err_d(t))])
end

% find best hyperparam set
[min_ELM_hist_eval, min_ind_d] = min(test_err_d);
disp(['Min value in ELM_list_fval: ', num2str(min_ELM_hist_eval)]);
hyp_d_pretr = [hyp_d_list(min_ind_d, :), nnd_list(min_ind_d)];
[~, beta_start, ~, ~] = optELM(hyp_d_pretr, samp_train, samp_labels_train);

% plot results of hyperparameter pre-training
figure;
subplot(2,2,1)
plot_D_train_err_comp(train_err_d_np, train_err_d, nnd_list)
subplot(2,2,2)
plot_D_train_test_err_comp(train_err_d, test_err_d, nnd_list) 
subplot(2,2,3)
plot_D_hyp_dev(hyp_d_list, nnd_list)
subplot(2,2,4)
plot_D_output_weights(beta_start)

%% ESN PRE-TRAINING

% initialize
n_runs = 1; % specify number of training runs
hyp_g_start_no = [1, 1]; % set hyperparameters which are Not Optimized
nng_list = 50:50:700; % specify a list with number of neurons
len_nng_list = length(nng_list);
hyp_g_list = zeros(len_nng_list, 2);
train_err_g_np = zeros(n_runs, len_nng_list);
train_err_g = zeros(n_runs, len_nng_list);
test_err_g = zeros(n_runs, len_nng_list);

% determine training length, testing length, time lag for prediction
N_G_train = 500;
N_G_test = 200;
pred_lag = 1;

% set input, split into training and testing part
z_init = ts_preprocess(ts_sp500_pp);
z_train = z_init(:, 1:(N_G_train*2));
z_test = z_init(:, (N_G_train*2)+1-N_G_test:(N_G_train*2)+N_G_test);

% set output
% NOTE: z_init(1,:) contains original time series
Y_train_target = z_init(1, N_G_train+1+pred_lag:(N_G_train*2)+pred_lag);
Y_test_target = z_init(1, (N_G_train*2)+1+pred_lag:(N_G_train*2)+N_G_test+pred_lag);

% run optimization procedure
for r = 1:n_runs
    for t = 1:len_nng_list
        % determine number of neurons
        N_tilde_G = nng_list(t);
    
        % training step
        train_err_g_np(r, t) = optESN([hyp_g_start_no, N_tilde_G], z_train, ...
            Y_train_target, N_G_train, r);
        funG = @(g_scale) optESN([g_scale, N_tilde_G], z_train, ...
            Y_train_target, N_G_train, r);
        options = optimoptions('fmincon','Display','iter','MaxIterations',100, ...
            'OptimalityTolerance',1e-4);
        [hyp_g_temp, ~] = fmincon(funG, hyp_g_start_no, [], [], [], [], ...
            [0.01,0.01], [10,1.2], [], options);
        hyp_g_list(t, :) = hyp_g_temp;
        %     hyp_g_temp = hyp_g_list(t,:);
        [train_err_g(r, t), theta_temp, c_temp, A_temp] = ...
            optESN([hyp_g_temp, N_tilde_G], z_train, Y_train_target, N_G_train, r);
        %      train_err_g(t) = train_err_temp;
        
        % testing step
        Y_test_temp = sample_gen(z_test, theta_temp, N_tilde_G, N_G_test, ...
            c_temp, A_temp);
        test_err_g(r, t) = RMSE(Y_test_temp, Y_test_target);
        
        % display current status
        disp(['N_tilde_G: ', num2str(N_tilde_G), ...
            ', MSE train (no opt.): ', num2str(train_err_g_np(r, t)), ...
            ', MSE train (opt.): ', num2str(train_err_g(r, t)), ...
            ', MSE test: ', num2str(test_err_g(r, t))])
    end
end

% set optimal number of hidden nodes to 150 (see thesis for reasons)
N_tilde_G_opt = 150; 

% find optimal hyperparameters and parameters
hyp_g_pretr = [hyp_g_list(find(nng_list==N_tilde_G_opt), :), N_tilde_G_opt];
[~, theta_start, c_start, A_start] = optESN(hyp_g_pretr, z_train, ...
    Y_train_target, N_G_train, r);

% % ALTERNATIVE: find optimal hyperparameters
% [min_ESN_hist_eval, min_val_ind_g] = min(test_err_g);
% disp(['Min value in min_ESN_hist_eval: ', num2str(min_ESN_hist_eval)]);
% hyp_g_pretr = [hyp_g_list(min_val_ind_g, :), nng_list(min_val_ind_g)];

% generated predictions on the testing set
Y_test = sample_gen(z_test, theta_start, N_tilde_G_opt, N_G_test, ...
    c_start, A_start);
pred_err = abs(Y_test_target-Y_test);

% plot results of hyperparameter pre-training
figure;
subplot(2,2,1)
plot_G_train_err_comp(train_err_g_np, train_err_g, nng_list, N_G_train)
subplot(2,2,2)
plot_G_train_test_err_comp(train_err_g, test_err_g, nng_list, N_G_train)
subplot(2,2,3)
plot_G_hyp_dev(hyp_g_list, nng_list, N_G_train)
subplot(2,2,4)
plot_pred_act_comp(Y_test_target, Y_test)

% plot optimal parameter vector theta
plot_G_output_weights(theta_start)

%% ANALYSIS OF IMPACT OF SPECTRAL RADIUS ON FORECASTING ERROR

% use a_{scale, opt} = 0.0139, N_{G, opt} = 150 for this analysis

% initialize
sr_int = 0.01:0.01:1; % interval of spectral radii (sr)
sr_int_len = length(sr_int);
train_err_g_sr = zeros(1, sr_int_len);
test_err_g_sr = zeros(1, sr_int_len);
t = 1;

for sr = sr_int
    % training step
    [train_err_g_sr(t), theta_temp, c_temp, A_temp] = ...
        optESN([hyp_g_pretr(1), sr, hyp_g_pretr(3)], z_train, Y_train_target, N_G_train, r);
    
    % testing step
    Y_test_temp = sample_gen(z_test, theta_temp, hyp_g_pretr(3), N_G_test, c_temp, A_temp);
    test_err_g_sr(t) = RMSE(Y_test_temp, Y_test_target);
    t = t+1;
end

% plot analysis results
plot_G_sr_dev(sr_int, test_err_g_sr)

%% ANALYSIS OF IMPACT OF DIFFERENT TRAINING LENGTHS

% compare optimal hyperparameters
figure;
subplot(2,2,1)
plot_G_hyp_dev(T1_hyp_g_list, T1_nng_list, 1000)
subplot(2,2,2)
plot_G_hyp_dev(T2_hyp_g_list, T2_nng_list, 1200)
subplot(2,2,3)
plot_G_hyp_dev(T3_hyp_g_list, T3_nng_list, 1400)
subplot(2,2,4)
plot_G_hyp_dev(T4_hyp_g_list, T4_nng_list, 1600)
sgtitle('Comparison of optimal hyperparameters')

% compare training errors
figure; 
subplot(2,2,1)
plot_G_train_err_comp(T1_train_err_g_np, T1_train_err_g, T1_nng_list, 1000)
subplot(2,2,2)
plot_G_train_err_comp(T2_train_err_g_np, T2_train_err_g, T2_nng_list, 1200)
subplot(2,2,3)
plot_G_train_err_comp(T3_train_err_g_np, T3_train_err_g, T3_nng_list, 1400)
subplot(2,2,4)
plot_G_train_err_comp(T4_train_err_g_np, T4_train_err_g, T4_nng_list, 1600)
sgtitle('Comparison of training errors')

% compare training and testing error
figure;
subplot(2,2,1)
plot_G_train_test_err_comp(T1_train_err_g, T1_test_err_g, T1_nng_list, 1000)
subplot(2,2,2)
plot_G_train_test_err_comp(T2_train_err_g, T2_test_err_g, T2_nng_list, 1200)
subplot(2,2,3)
plot_G_train_test_err_comp(T3_train_err_g, T3_test_err_g, T3_nng_list, 1400)
subplot(2,2,4)
plot_G_train_test_err_comp(T4_train_err_g, T4_test_err_g, T4_nng_list, 1600)
sgtitle('Comparison of training error and testing error')

%% ANALYSIS OF IMPACT OF DIFFERENT TIME LAGS ON FORECASTING ERROR

figure; 
hold on
plot(nng_list, test_err_g_L1, 'LineWidth', 2); 
plot(nng_list, test_err_g_L2, 'LineWidth', 2);
plot(nng_list, test_err_g_L3, 'LineWidth', 2);
plot(nng_list, test_err_g_L4, 'LineWidth', 2);
plot(nng_list, test_err_g_L5, 'LineWidth', 2);
title('Development of testing errors for different time lags')
xlabel('Number of hidden nodes')
ylabel('MSE')
legend('t+1', 't+2', 't+3', 't+4', 't+5')
hold off

%% PLOT OUTPUT SETS

figure; 
plot(1:N_G_train, Y_train_target, 'LineWidth', 2)
hold on
plot(N_G_train+1:N_G_train+N_G_test, Y_test_target, 'LineWidth', 2)
xlim([1 N_G_train+N_G_test])
title('Training and testing output')
xlabel('Time')
ylabel('Value')
hold off

%% INITIALIZE HYPERPARAMETERS AND PARAMETERS FOR GAN TRAINING

% set learning rates
rng('default')
lr_d = 1e-2; % 1e-3, 1e-2 works fine 
lr_g = 5e-2; % 3e-3, 1e-1 works fine
lr = [lr_d, lr_g];

% set hyperparameters
hyp_d = hyp_d_pretr;
hyp_g = hyp_g_pretr;

% set parameters
beta = beta_start;
theta = theta_start;

% calculate weight matrices for ELM
[a, b] = compute_ELM_weights(hyp_d, T);

% calculate weight matrices for ESN
N_z = 3; % same choice as for Quant GAN
intercept = 0; 
[c, A] = compute_ESN_weights(hyp_g, N_z, intercept);

% #########################################################################
% NOTE: weights matrices for discriminator and generator will not be 
% changed during GAN training
% #########################################################################

%% GAN TRAINING

% initialize
num_epochs = 200;
hist_beta = zeros(length(beta), num_epochs);
hist_theta = zeros(num_epochs, length(theta));
hist_d_loss_real = zeros(1, num_epochs);
hist_d_loss_fake = zeros(1, num_epochs);
hist_d_loss = zeros(1, num_epochs);
hist_g_loss = zeros(1, num_epochs);
grad_d_norm = zeros(1, num_epochs);
grad_g_norm = zeros(1, num_epochs);
hist_grad_d_loss = zeros(hyp_d_pretr(3), num_epochs);
hist_grad_g_loss = zeros(num_epochs, hyp_g_pretr(3));
m_d = zeros(length(beta), num_epochs+1);
v_d = zeros(length(beta), num_epochs+1);
m_hat_d = zeros(length(beta), num_epochs+1);
v_hat_d = zeros(length(beta), num_epochs+1);
m_g = zeros(num_epochs+1, length(theta));
v_g = zeros(num_epochs+1, length(theta));
m_hat_g = zeros(num_epochs+1, length(theta));
v_hat_g = zeros(num_epochs+1, length(theta));

% initialize
figure; clf; 

% while maximal number of epochs is not reached, do GAN training
for epoch = 1:num_epochs

% display current epoch
disp(['Epoch ', num2str(epoch), '/', num2str(num_epochs)])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% optimize discriminator's parameters (beta)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % for all discriminator optimization steps do
    for k=1:d_opt_steps
        
        % shuffle random seed
        rng('shuffle')
        
        % initialize beta for discriminator
        beta_input = beta;

        % sample from real data distribution
        ind_gan_real = randperm(samp_size, M);
        samp_real_gan = samp_real_all(ind_gan_real, :);

        % sample from fake data distribution
        z = randn(N_z, T + 1.5 * hyp_g(3), M);  
        samp_fake_gan = sample_gen(z, theta, hyp_g(3), T, c, A);
      
        % ### run discriminator training step ###
        % calculate discriminator's loss and optimized beta
        [d_loss_real, d_loss_fake, beta, hist_grad_d_loss, ...
            m_d, v_d, m_hat_d, v_hat_d] = ...
            d_trainstep(samp_real_gan, samp_fake_gan, beta_input, ...
                                a, b, lr_d, hist_grad_d_loss, epoch, ...
                                m_d, v_d, m_hat_d, v_hat_d);
        grad_d_norm(epoch) = norm(hist_grad_d_loss(:, epoch));
        
        % collect parameters and training loss
        hist_beta(:, epoch) = beta;
        hist_d_loss(epoch) = d_loss_real + d_loss_fake;
        hist_d_loss_real(epoch) = d_loss_real;
        hist_d_loss_fake(epoch) = d_loss_fake;

    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% optimize generator's parameter (theta)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % shuffle random seed
    rng('shuffle')
    
    % initialize parameter theta for generator
    theta_input = theta;
    
    % sample from fake latent prior distribution (Gaussian distribution)
    z = randn(N_z, T + 1.5 * hyp_g(3), M);

    % ### run generator training step ###
    % calculate generator's loss and optimized theta
    [g_loss, theta, G_z, hist_grad_g_loss, m_g, v_g, m_hat_g, v_hat_g] = ...
        g_trainstep(z, T, beta, a, b, theta_input, hyp_g(3), lr_g, ...
        hist_grad_g_loss, epoch, m_g, v_g, m_hat_g, v_hat_g, c, A);
    grad_g_norm(epoch) = norm(hist_grad_g_loss(epoch, :));
    
    % collect parameters and training loss
    hist_theta(epoch, :) = theta;
    hist_g_loss(epoch) = g_loss;
    
    % display status for epoch
    plot_GAN_epoch_status(samp_real_gan, samp_fake_gan, M, hist_d_loss_real, ...
        hist_d_loss_fake, hist_g_loss, epoch);
    
end

% store optimized parameters after GAN training
beta_opt = beta;
theta_opt = theta;

%% PLOT INITIAL VS. OPTIMIZED PARAMETERS FROM GAN TRAINING

% plot the comparison between initial parameters and optimized parameters
% for the discriminator
subplot(1, 2, 2)
plot(beta_opt, 'DisplayName', '\beta_{opt}', 'LineWidth', 1)
hold on
plot(beta_start, 'DisplayName', '\beta_{start}', 'LineWidth', 1)
xlim([1 hyp_d(3)])
hold off
title('Comparison of \beta')
xlabel('Neuron')
ylabel('Value')
legend

% plot the comparison between initial parameters and optimized parameters
% for the generator
fig_comp_parameters = figure;
subplot(1, 2, 1)
plot(theta_opt, 'DisplayName', '\theta_{opt}', 'LineWidth', 1)
hold on
plot(theta_start, 'DisplayName', '\theta_{start}', 'LineWidth', 1)
xlim([1 hyp_g(3)])
hold off
title('Comparison of \theta')
xlabel('Neuron')
ylabel('Value')
legend

%% PLOT GAN TRAINING LOSSES

fig_training_losses = figure;
hold on
plot(hist_d_loss_real, 'DisplayName', 'd loss real', 'LineWidth', 2, 'Color', 'blue')
plot(hist_d_loss_fake, 'DisplayName', 'd loss fake', 'LineWidth', 2, 'Color', '#D95319')
plot(hist_g_loss, 'DisplayName', 'g loss', 'LineWidth', 2, 'Color', 'green')
xlabel('epoch')
ylabel('loss')
xlim([0 num_epochs])
title('Development of GAN training loss')
legend
hold off

%% EVALUATE TRAINED GENERATOR

% shuffle random seed
rng('shuffle')

% generate synthetic paths
z_test = randn(N_z, len_ts_sp500 + 1.5 * hyp_g(3), M);
x_fake = sample_gen(z_test, theta_opt, hyp_g(3), len_ts_sp500, c, A); % generated log-returns
x_fake_norm = (x_fake-mean(x_fake, 'all'))/std(x_fake, 0, 'all');
x_fake_raw = sample_inv_transform(x_fake_norm, mean_ts_sp500, std_ts_sp500);
gen_paths = ts_sp500(1) .* x_fake_raw;
real_path = ts_sp500 ./ ts_sp500(1);

% plot 50 synthetic paths and original S&P 500 path
plot_paths_comp(ts_sp500, gen_paths, 50)

% compare histograms of historical and synthetic densities
plot_hist_comp(real_path, x_fake_raw)
