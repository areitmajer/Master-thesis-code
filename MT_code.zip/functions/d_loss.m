function [d_loss_sum, d_loss_real, d_loss_fake] = d_loss(x_real, x_fake, beta, a, b)
% calculate discriminator's loss on real and fake samples

% #########################################################################
% INPUT 1: x_real (real input samples)
% INPUT 2: x_fake (fake input samples)
% INPUT 3: beta (output weights of discriminator)
% INPUT 4: a (input weight matrix)
% INPUT 5: b (hidden biases)
% OUTPUT 1: d_loss_sum (cumulated loss of discriminator)
% OUTPUT 2: d_loss_real (loss of the discriminator related to real samples)
% OUTPUT 3: d_loss_fake (loss of the discriminator related to fake samples)
% #########################################################################

% plausibility check
if ~(size(x_real, 1) == size(x_fake, 1))
    error('Number of samples for real and fake samples does not coincide!')
end

% classification of real and fakes samples
d_real = disc(x_real, beta, a, b);
d_fake = disc(x_fake, beta, a, b);

% apply activation function on classifications
D_real = sigmoid(d_real);
D_fake = sigmoid(d_fake);

% calculation of loss
d_loss_real = -mean(log(D_real));
d_loss_fake = -mean(log(1-D_fake));
d_loss_sum = d_loss_real + d_loss_fake;

end