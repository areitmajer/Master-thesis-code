 function [Y, S] = gen(z, theta, nng, T, c, A)
% ESN function

% #########################################################################
% INPUT 1: z (input set)
% INPUT 2: theta (output weights)
% INPUT 3: nng (number of neurons in the generator)
% INPUT 4: T (number of datapoints in each sample)
% INPUT 5: c (input weight matrix)
% INPUT 6: A (output weight matrix)
% OUTPUT 1: Y (ESN's output)
% OUTPUT 2: S (reservoir states matrix gathered during ESN procedure)
% #########################################################################

% initialize
N_u = size(z, 1);
len_z = size(z, 2);
M = size(z, 3);
intercept = 0;
nng_min = nng-1;

% collect the reservoir activation states and calculate network outputs
x_hat = zeros(nng_min, len_z+1, M);
Y = zeros(M, T);
S = zeros(nng, T, M);
for i=1:M
    for t=2:len_z+1
        if intercept == 1
            x_hat(:, t, i) = tanh(c*[1; z(:, t-1, i)] + A*x_hat(:, t-1, i));
        else
            x_hat(:, t, i) = tanh(c*z(:, t-1, i) + A*x_hat(:, t-1, i));
        end
    end
    S(:,:,i) = [ones(1, T); x_hat(:, end-T+1:end, i)];
    Y(i, :) = theta * S(:,:,i);
end
