function plot_G_train_err_comp(train_err_g_np, train_err_g, nng_list, N_G_train)
% plot comparison of optimized vs. non-optimized training errors for the
% generator

% #########################################################################
% INPUT 1: train_err_g_no (non-optimized generator's training errors)
% INPUT 2: train_err_g (optimized generator's training errors)
% INPUT 3: nng_list (list of number of neurons)
% INPUT 4: N_G_train (specification of training length)
% OUTPUT: plot
% #########################################################################

plot(nng_list, train_err_g_np, 'Color', 'cyan', 'LineWidth', 2); 
hold on
plot(nng_list, train_err_g, 'Color', 'blue', 'LineWidth', 2);
legend({'no hyp. opt.', 'applied hyp. opt.'}, 'Location', 'northeast')
xlim([nng_list(1), nng_list(end)])
% title(['N_GTrain= ', num2str(N_G_train)])
title('a) Training errors')
% subtitle('(Generator)')
xlim([nng_list(1), nng_list(end)])
xlabel('Number of hidden nodes')
ylabel('RMSE')
hold off

end