function res = log_r(x, k)
% calculate k-th log-return
res = log(x(:,1+k:end)./x(:,1:end-k));
end