function plot_G_output_weights(theta)
% plot output weights of generator

% #########################################################################
% INPUT: theta (obtained output weights)
% OUTPUT: plot
% #########################################################################

figure; 
plot(theta, 'LineWidth', 2); 
title('Output weights \theta'); 
xlabel('Neuron'); 
ylabel('Value'); 
hold off

end