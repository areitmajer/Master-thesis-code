function plot_GAN_epoch_status(x_real, x_fake, dim, hist_d_loss_real, ...
    hist_d_loss_fake, hist_g_loss, epoch)
% plot status of GAN for each epoch

% #########################################################################
% INPUT 1: x_real (set of real samples)
% INPUT 2: x_fake (set of fake samples)
% INPUT 3: dim (dimension)
% INPUT 4: hist_d_loss_real (loss of discriminator on real samples)
% INPUT 5: hist_d_loss_fake (loss of discriminator on fake samples)
% INPUT 6: hist_g_loss (loss of generator)
% INPUT 7: epoch (specification of epoch number)
% OUTPUT: plot
% #########################################################################

subplot(1, 2, 1)
hold on
cla
for i=1:dim
    plot(x_real(i,:), 'Color', 'blue')
    plot(x_fake(i,:), 'Color', 'red')
end
xlim([0, size(x_real, 2)])
title('real (blue) and fake (red) training samples')
hold off

subplot(1, 2, 2)
hold on
cla
plot(hist_d_loss_real, 'DisplayName', 'd loss real', 'LineWidth', 2, 'Color', 'blue')
plot(hist_d_loss_fake, 'DisplayName', 'd loss fake', 'LineWidth', 2, 'Color', '#D95319')
plot(hist_g_loss, 'DisplayName', 'g loss', 'LineWidth', 2, 'Color', 'green')
xlabel('number of epochs')
ylabel('loss')
xlim([0 epoch])
title('training loss')
legend
hold off

drawnow()

end