function res = log_der(x)
% log derivative
res = 1./x;
end