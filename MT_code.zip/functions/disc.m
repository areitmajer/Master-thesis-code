function p = disc(x, beta, a, b)
% ELM function

% #########################################################################
% INPUT 1: x (time series to be classified)
% INPUT 2: beta (output weights)
% INPUT 3: a (input weight matrix)
% INPUT 4: b (hidden bias)
% OUTPUT: p (ELM's classification output)
% #########################################################################

% determine number of samples
M = size(x, 1);

% calculate hidden layer output matrix
H = x*a + repmat(b, M, 1);

% apply radbas activation function on H
H_act = radbas(H);

% calculate probability
p = H_act * beta;

end