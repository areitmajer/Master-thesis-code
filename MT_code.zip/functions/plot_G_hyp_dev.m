function plot_G_hyp_dev(hyp_g_list, nng_list, N_G_train)
% plot development of optimal hyperparameters for the generator

% #########################################################################
% INPUT 1: hyp_g_list (list of optimal hyperparameters for the generator)
% INPUT 2: nng_list (list of number of neurons)
% INPUT 3: N_G_train (specification of training length)
% OUTPUT: plot
% #########################################################################

len_nng_list = length(nng_list);
plot(nng_list, hyp_g_list(:,1), 'LineWidth', 2);
hold on
plot(nng_list, hyp_g_list(:,2), 'LineWidth', 2);
mean_c_scale = mean(hyp_g_list(3:end,1)); % discard underfitting values
mean_A_SR = mean(hyp_g_list(3:end,2)); % discard underfitting values
plot(nng_list, repmat(mean_c_scale, 1, len_nng_list), '--', 'LineWidth', 2);
plot(nng_list, repmat(mean_A_SR, 1, len_nng_list), '--', 'LineWidth', 2);
xlim([nng_list(1), nng_list(end)])
legend({'c_{scale}', 'A_{SR}', 'mean c_{scale}', 'mean A_{SR}'}, 'Location', 'northeast')
% title(['N_GTrain= ', num2str(N_G_train)])
title('c) Optimal hyperparameter values')
% subtitle('(Generator)')
xlabel('Number of hidden nodes')
ylabel('Hyperparameter value')
hold off

end