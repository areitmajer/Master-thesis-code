function z = ts_preprocess(ts)
% preprocess time series

% #########################################################################
% INPUT: ts (time series)
% OUTPUT: z (preprocessed time series)
% #########################################################################

% specify moving average type
max_ma = 5;

% initialize z
z = zeros(2, length(ts)-max_ma);

% first row: original time series
z(1,:) = ts(1:length(ts)-max_ma);

for t = 1:length(ts)-max_ma
    % second row: modified 5-day MA
    z(2,t) = mean(ts(t:t+max_ma));
end

end