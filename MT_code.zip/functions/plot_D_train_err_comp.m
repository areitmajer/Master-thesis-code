function plot_D_train_err_comp(train_err_d_np, train_err_d, nnd_list)
% plot comparison of optimized vs. non-optimized training errors for the
% discriminator

% #########################################################################
% INPUT 1: train_err_d_no (non-optimized training errors of the discriminator)
% INPUT 2: train_err_d (optimized training errors of the discriminator)
% INPUT 3: nnd_list (list of number of hidden nodes)
% OUTPUT: plot
% #########################################################################

plot(nnd_list, train_err_d_np, 'Color', 'cyan', 'LineWidth', 2); 
hold on
plot(nnd_list, train_err_d, 'Color', 'blue', 'LineWidth', 2);
legend('Error without hyperparameter optimization', ...
    'Error with hyperparameter optimization')
title('a) Comparison of training errors')
subtitle('(Discriminator)')
xlabel('Number of hidden nodes')
ylabel('Mod. F1 score')
hold off

end