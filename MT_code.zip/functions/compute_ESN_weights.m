function [c, A] = compute_ESN_weights(hyp_g, N_u, intercept, rand_seed)
% ESN weights computation function

% #########################################################################
% INPUT 1: hyp_g (generator's hyperparameters)
% INPUT 2: N_u (number of input units)
% INPUT 3: intercept (existence of intercept)
% INPUT 4: rand_seed (specification of random seed)
% OUTPUT 1: c (input weight matrix)
% OUTPUT 2: A (reservoir weight matrix)
% #########################################################################

% initialize
nng_min = hyp_g(3)-1;
rng(rand_seed)

% generate input mask c (dense, symmetrically uniformly distributed) 
if intercept == 1
    c = -1 + 2.*rand(nng_min, N_u+1); % with intercept
else
    c = -1 + 2.*rand(nng_min, N_u); % without intercept
end

% generate reservoir matrix A (sparse, symmetrical uniform distribution)
W = sprand(nng_min, nng_min, 0.01);
W((W~=0)) = -1+2.*W((W~=0));
opt.disp = 0;
rho_W = max(abs(eigs(W,1,'LM',opt)));
W_1 = (W / rho_W);

% apply scaling to input mask c
c_scale = hyp_g(1);
c = c_scale.*c;

% apply scaling to reservoir matrix W_1
A_SR = hyp_g(2);
A = A_SR.*W_1;

end
