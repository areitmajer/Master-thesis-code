function [x_out, samp_mean, samp_std] = sample_transform(x, flag)
% transform input sample

%##########################################################################
% INPUT 1: x (input sample)
% INPUT 2 (optional): flag 
% OUTPUT 1: x_out (transformed sample)
% OUTPUT 2: samp_mean (mean of differenced sample)
% OUTPUT 3: samp_std (standard deviation of differenced sample)
%##########################################################################

if flag
    % apply log transform
    x_log = log(x);

    % apply difference transform
    x_diff = fun_diff(x_log);

else
    x_diff = x;
end

% apply standard scaler
x_norm = normalize(x_diff, 2);
samp_mean = mean(x_diff);
samp_std = std(x_diff);

% return transformed sample
x_out = x_norm;

end