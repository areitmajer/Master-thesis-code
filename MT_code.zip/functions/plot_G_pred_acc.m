function plot_G_pred_acc(Y_test_target, Y_test)
% plot comparison between desired target output and generated output

% #########################################################################
% INPUT 1: Y_test_target (desired target output of test set)
% INPUT 2: Y_test (generated output on the testing data with the trained
% ESN)
% OUTPUT: plot
% #########################################################################

plot(Y_test_target, 'LineWidth', 2); hold on; plot(Y_test, 'LineWidth', 2);
legend('Y_{test}^{target}', 'Y_{test}')
xlim([1, length(Y_test)])
title('d) Predicted vs. desired output')
% subtitle('(Generator)')
hold off

end