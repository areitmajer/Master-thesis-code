function [d_real_end, d_fake_end, beta_opt, hist_grad_d_loss, m, v, m_hat, v_hat] ...
    = d_trainstep(x_real, x_fake, beta_in, a, b, lr, ...
        hist_grad_d_loss, epoch, m, v, m_hat, v_hat)
% calculate discriminator's loss and gradient

% #########################################################################
% INPUT 1: x_real (set of real samples)
% INPUT 2: x_fake (set of fake samples)
% INPUT 3: beta_in (output weights for discriminator used as input)
% INPUT 4: a (input weight matrix)
% INPUT 5: b (hidden biases)
% INPUT 6: lr (learning rate)
% INPUT 7: hist_grad_d_loss (history of discriminator's gradients loss)
% INPUT 8: epoch (number of epoch)
% INPUT 9: m (biased mean estimate for ADAM)
% INPUT 10: v (biased variance estimate for ADAM)
% INPUT 11: m_hat (biased-corrected mean estimate for ADAM)
% INPUT 12: v_hat (biased-corrected variance estimate for ADAM)
% OUTPUT 1: d_real_end (discriminator's loss on real samples after update)
% OUTPUT 2: d_fake_end (discriminator's loss on fake samples after update)
% OUTPUT 3: beta_opt (optimized discriminator's output weights)
% OUTPUT 4: hist_grad_d_loss (history of discriminator's gradients loss)
% OUTPUT 5: m (biased mean estimate for ADAM)
% OUTPUT 6: v (biased variance estimate for ADAM)
% OUTPUT 7: m_hat (biased-corrected mean estimate for ADAM)
% OUTPUT 8: v_hat (biased-corrected variance estimate for ADAM)
% #########################################################################

% initialize
M = size(x_real, 1);

% select optimizer type (either SGD or ADAM)
D_optimizer = "ADAM";

% plausibility check
if ~(size(x_real, 1) == size(x_fake, 1))
    error('Number of real and fake samples does not coincide!')
end

% display status
disp('Train discriminator')

% initialize
beta = beta_in;

% initialize
batch_size = M;
samp_real = x_real;
samp_fake = x_fake;

% calculate gradients
d_real = disc(samp_real, beta, a, b);
d_fake = disc(samp_fake, beta, a, b);
grad_d_real = radbas(samp_real*a + repmat(b, batch_size, 1));
grad_d_fake = radbas(samp_fake*a + repmat(b, batch_size, 1));
grad_real = sum(-(1/batch_size) .* log_der(sigmoid(d_real)) .* sigmoid_der(d_real) .* grad_d_real);
grad_fake = sum(-(1/batch_size) .* log_der(1-sigmoid(d_fake)) .* (-sigmoid_der(d_fake)) .* grad_d_fake);
grad_d_loss = (grad_real + grad_fake)';

% store gradient of discriminator loss
hist_grad_d_loss(:,epoch) = grad_d_loss;

if D_optimizer == "SGD"
    beta_opt = beta - lr .* grad_d_loss;
elseif D_optimizer == "ADAM"
    beta_1 = 0.9;
    beta_2 = 0.999;
    adam_eps = 1e-8;
    m(:,epoch+1) = beta_1.*m(:,epoch) + (1-beta_1).*grad_d_loss;
    v(:,epoch+1) = beta_2.*v(:,epoch) + (1-beta_2).*grad_d_loss.^2;
    m_hat(:,epoch+1) = m(:,epoch+1)./(1-beta_1.^epoch);
    v_hat(:,epoch+1) = v(:,epoch+1)./(1-beta_2.^epoch);
    beta_opt = beta - ((lr./(sqrt(v_hat(:,epoch+1)) + adam_eps)).*m_hat(:,epoch+1));
else
    error('Please enter a valid optimizer type!')
end

% check optimized beta for NaN entries
if sum(isnan(beta_opt)) > 0
    error('NaN entry found in parameter beta_opt!')
end

% calculate discriminator's real and fake loss with optimized beta
[~, d_real_end, d_fake_end] = d_loss(x_real, x_fake, beta_opt, a, b);

end