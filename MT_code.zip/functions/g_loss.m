function loss = g_loss(z, theta, nng, T, c, A, beta, a, b)
% calculate generator's loss

% #########################################################################
% INPUT 1: z (input samples)
% INPUT 2: theta (output weights of generator)
% INPUT 3: nng (number of neurons contained in generator)
% INPUT 4: T (number of datapoints in each sample)
% INPUT 5: c (input weight matrix of generator)
% INPUT 6: A (reservoir weight matrix of generator)
% INPUT 7: beta (output weights of discriminator)
% INPUT 8: a (input weight matrix of discriminator)
% INPUT 9: b (hidden biases of discriminator)
% OUTPUT: loss (generator's loss)
% #########################################################################

G_z = sample_gen(z, theta, nng, T, c, A);
d_fake = disc(G_z, beta, a, b);
D_fake = sigmoid(d_fake);
loss = -mean(log(D_fake));
end