function plot_D_hyp_dev(hyp_d_list, nnd_list)
% plot development of optimal hyperparameters for the discriminator

% #########################################################################
% INPUT 1: hyp_d_list (list of optimal discriminator's hyperparameters)
% INPUT 2: nnd_list (list of number of hidden nodes)
% OUTPUT: plot
% #########################################################################

len_nnd_list = length(nnd_list);
plot(nnd_list, hyp_d_list(:,1), 'LineWidth', 2);
hold on
plot(nnd_list, hyp_d_list(:,2), 'LineWidth', 2);
mean_a_scale = mean(hyp_d_list(:,1));
mean_b_scale = mean(hyp_d_list(:,2));
plot(nnd_list, repmat(mean_a_scale, 1, len_nnd_list), '--', 'LineWidth', 2);
plot(nnd_list, repmat(mean_b_scale, 1, len_nnd_list), '--', 'LineWidth', 2);
legend({'a_{scale}', 'b_{scale}', 'mean a_{scale}', 'mean b_{scale}'}, 'Location', 'northwest')
title('c) Development of hyperparameter optimization')
subtitle('(Discriminator)')
xlim([nnd_list(1), nnd_list(end)])
xlabel('Number of hidden nodes')
ylabel('Value')
hold off

end