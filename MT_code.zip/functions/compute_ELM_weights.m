function [a, b] = compute_ELM_weights(hyp_d, num_obs)
% ELM weights computation function

% #########################################################################
% INPUT 1: hyp_d (discriminator hyperparameters)
% INPUT 2: num_obs (number of observations in each sample)
% OUTPUT 1: a (input weight matrix)
% OUTPUT 2: b (hidden biases)
% #########################################################################

% define scalings
a_scale = hyp_d(1);
b_scale = hyp_d(2);
nnd = hyp_d(3);

% fix random seed
rng('default')

% randomly assign weights for parameters of hidden nodes
a = a_scale.*(-1+2.*rand(num_obs, nnd)); % symmetric uniform distribution ([-a_scale, a_scale])
b = b_scale.*(-1+2.*rand(1, nnd)); % symmetric uniform distribution ([-b_scale, b_scale])

end