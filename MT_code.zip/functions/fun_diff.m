function res = fun_diff(x)
res = x(:,2:end)-x(:,1:end-1);
end