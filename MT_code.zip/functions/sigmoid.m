function x = sigmoid(z)
% sigmoid function
x = 1 ./ (1 + exp(-z));
end